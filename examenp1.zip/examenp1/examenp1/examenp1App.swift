//
//  examenp1App.swift
//  examenp1
//
//  Created by Zurisabdai Núñez Velázquez on 15/09/25.
//

import SwiftUI

@main
struct examenp1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
