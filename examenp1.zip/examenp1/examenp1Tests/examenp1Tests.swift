//
//  examenp1Tests.swift
//  examenp1Tests
//
//  Created by Zurisabdai Núñez Velázquez on 15/09/25.
//

import Testing
@testable import examenp1

struct examenp1Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
