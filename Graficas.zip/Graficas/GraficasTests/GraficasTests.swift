//
//  GraficasTests.swift
//  GraficasTests
//
//  Created by Zurisabdai Núñez Velázquez on 26/09/25.
//

import Testing
@testable import Graficas

struct GraficasTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
