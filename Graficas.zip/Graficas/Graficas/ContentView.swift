//
//  ContentView.swift
//  Graficas
//
//  Created by Zurisabdai Núñez Velázquez on 26/09/25.
//

import Charts
import SwiftUI

struct ContentView: View {
    var body: some View {
        PantallaInicialView()
    }
}

#Preview {
    ContentView()
}
