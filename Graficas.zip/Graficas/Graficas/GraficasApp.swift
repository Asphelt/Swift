//
//  GraficasApp.swift
//  Graficas
//
//  Created by Zurisabdai Núñez Velázquez on 26/09/25.
//

import SwiftUI

@main
struct GraficasApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
