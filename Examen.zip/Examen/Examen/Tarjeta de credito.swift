//
//  Tarjeta de credito.swift
//  Examen
//
//  Created by WIN603 on 03/10/25.
//

import SwiftUI

struct Tarjeta_de_credito: View {
    @State var nombre: String = ""
    @State var imagen: String = ""
    @State var titular: String = ""
    @State var numero: String = ""
    @State var tipo: Int = 0
    @State var color : Color = (Color(red:23/255,green:32/255,blue:35/255))
    @State private var angulo : Angle = .degrees(0)
    @State var gris : Color = .gray
    @State var estado : Bool = false
    @State var frame: CGSize = CGSize(width: 350, height: 180)
    @State var frame2: CGSize = CGSize(width: 350, height: 140)
    @State var scale_effect : CGFloat = 1
    @State var sinFavorito : String =  "star"
    @State var favorito_estado : Bool = false
    
    var id:Int
    @Binding var contador : Int
    
    func favoritos() -> String{
        if contador == id{
            return "star.fill"
           
                
        }
        else{
            return "star"
        }
        
      
    }
    
    var body: some View {
        VStack{
            HStack{
                ZStack{
                    /*if !estado{
                        Rectangle()
                            .fill(color)
                            .frame(width: 350, height: 180)
                            .cornerRadius(20)
                    }else{
                        Rectangle()
                            .fill(gris)
                            .frame(width: 350, height: 180)
                            .cornerRadius(20)
                    }*/
                   
                    Rectangle()
                        .fill(estado ? gris : color)
                        .frame(
                            width: estado ? frame2.width : frame.width,
                            height: estado ? frame2.height : frame.height
                        )
                        


                        .cornerRadius(20)
                        .animation(.easeInOut(duration: 4), value: estado)

                    
                    HStack(){
                        Text(nombre)
                            .fontWeight(.bold)
                            .font(.system(size: 20, weight: .bold, design: .default))
                            .foregroundStyle(.white)
                            .padding(EdgeInsets(top: 0, leading: 30, bottom: 100, trailing: 0))
                        Image(imagen)
                            .resizable()
                            .frame(width: 30, height: 30)
                            .scaledToFit()
                            .padding(EdgeInsets(top: 0, leading: 5, bottom: 100, trailing: 0))
                        
                        
                        Button(action:{
                            withAnimation(.easeInOut(duration: 1)){
                                favorito_estado.toggle()
                                self.contador = self.id
                                
                                
                            }
                           
                        }){
                            
                            Image(systemName: favoritos())
                                .frame(width: 30, height: 30)
                                .scaledToFit()
                                .padding(EdgeInsets(top: 0, leading: 5, bottom: 100, trailing: 0))
                                .foregroundStyle(.yellow)
                                
                            
                        }
                        
                        
                        
                        Spacer()
                        VStack{
                            Image("less02")
                                .resizable()
                                .frame(width: 40, height: 40)
                                .scaledToFit()
                                .padding(EdgeInsets(top: 0, leading: 5, bottom: 115, trailing: 30))
                        }
                    }
                    HStack(){
                        Text(estado ? "" :"2234 5678 9112 3456")
                            .foregroundStyle(.white)
                            .padding(EdgeInsets(top: 0, leading: 35, bottom: 30, trailing: 0))
                            .font(.system(size: 20, weight: .bold, design: .default))
                        
                        
                        Spacer()
                    }
                    HStack{
                        Text(estado ? "" :titular)
                            .padding(EdgeInsets(top: 12, leading: 35, bottom: 0, trailing: 0))
                            .foregroundStyle(.white)
                            .font(.system(size: 12, weight: .bold, design: .default))
                            .font(.caption2)
                        Spacer()
                    }
                    HStack{
                        Button(action:{
                            withAnimation(.easeInOut(duration: 2)){
                                angulo += .degrees(180)
                                estado.toggle()
                                if estado{
                                    scale_effect = -1

                                }else{
                                    scale_effect = 1

                                }
                                
                            }
                           
                        }){
                            
                            Image(systemName: "lock.fill")
                                .padding(EdgeInsets(top: 100, leading: 30, bottom: 0, trailing: 0))
                                .foregroundStyle(.white)
                            Text("Bloquear")
                                .padding(EdgeInsets(top: 100, leading: 0, bottom: 0, trailing: 0))
                                .foregroundStyle(.white)
                                
                            
                        }
                        
                       
                        Spacer()
                        HStack{
                            ZStack{
                                if tipo == 1{
                                    Circle()
                                        .fill(.white)
                                        .frame(width: 40, height: 40)
                                        .padding(EdgeInsets(top: 100, leading: 10, bottom: 0, trailing: 30))
                                        .foregroundStyle(.white)
                                   
                                    Text("VISA")
                                        .padding(EdgeInsets(top: 100, leading: 10, bottom: 0, trailing: 30))
                                        .fontWeight(.bold)
                                        .font(.system(size: 12, weight: .bold, design: .default))
                                        
                                }
                                if tipo == 2{
                                    Circle()
                                        .fill(Color(red:253/255,green:207/255,blue:1/255))
                                        .frame(width: 20, height: 20)
                                        .padding(EdgeInsets(top: 100, leading: 10, bottom: 0, trailing: 15))
                                        .foregroundStyle(.white)
                                    Circle()
                                        
                                        .fill(Color.blue)
                                        .frame(width: 20, height: 20)
                                        .padding(EdgeInsets(top: 100, leading: 10, bottom: 0, trailing: 45))
                                }
                                
                                
                                
                            }
                           
                        }
                        
                    }
                    
                }.rotationEffect(angulo)
                    .scaleEffect(x: scale_effect)
               
            }
        }
    }
}


#Preview {
    Tarjeta_de_credito(nombre: "Mercado Libre", imagen: "mp", titular: "Alexander Hernandez", numero: "2234 5678 91112 3456",tipo: 1,color: .blue,id: 0,contador: .constant(0))
}
