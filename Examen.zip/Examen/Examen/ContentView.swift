//
//  ContentView.swift
//  Examen
//
//  Created by WIN603 on 15/09/25.
//

import SwiftUI

struct ContentView: View {
    @State private var angulo : Angle = .degrees(0)
    @State private var color1 : Color = Color(red:236/255,green:32/255,blue:35/255)
    @State private var desabilitar : Color = .gray
    @State  var tarjetaFavorita: Int
    var body: some View {
        ScrollView(.vertical)
        {
            
      
        VStack {
            Text("Tarjetas de credito")
                .fontWeight(.bold)
                .font(.system(size: 30, weight: .bold, design: .default))
          
            Tarjeta_de_credito(nombre: "Mercado Libre", imagen: "mp", titular: "Alexander Hernandez", numero: "2234 5678 91112 3456",tipo: 1,color: (Color(red:23/255,green:32/255,blue:35/255)),id: 1, contador: $tarjetaFavorita)
            Tarjeta_de_credito(nombre: "Banamex", imagen: "bnmx", titular: "Gael Hernandez", numero: "2235 5678 91112 3456",tipo: 2,color: (Color(red:236/255,green:32/255,blue:35/255)),id: 2, contador: $tarjetaFavorita)
            Tarjeta_de_credito(nombre: "Stori", imagen: "stori2", titular: "Zuri Nuñez", numero: "2235 5638 91112 3456",tipo: 2,color: (Color(red:103/255,green:166/255,blue:157/255)),id: 3,contador: $tarjetaFavorita)
            Tarjeta_de_credito(nombre: "nu", imagen: "nu", titular: "Leonardo Hernandez", numero: "2235 5638 91112 3456",tipo: 2,color: (Color(red:156/255,green:68/255,blue:220/255)),id: 4,contador: $tarjetaFavorita)
            Tarjeta_de_credito(nombre: "HeyBanco", imagen: "hey", titular: "Andrick Hernandez", numero: "2235 5668 91112 3416",tipo: 2,color: (Color(red:0/255,green:0/255,blue:0/255)),id: 5,contador: $tarjetaFavorita)
           
       
            
        }
        
        
 
        Spacer()
    }
}
}

#Preview {
    ContentView(tarjetaFavorita: 0)
}
