//
//  ExamenApp.swift
//  Examen
//
//  Created by WIN603 on 15/09/25.
//

import SwiftUI

@main
struct ExamenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(tarjetaFavorita: 0)
        }
    }
}
