//
//  AvionSubmarinoApp.swift
//  AvionSubmarino
//
//  Created by Zurisabdai Núñez Velázquez on 06/10/25.
//

import SwiftUI

@main
struct AvionSubmarinoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
