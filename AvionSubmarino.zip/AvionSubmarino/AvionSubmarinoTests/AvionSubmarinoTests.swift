//
//  AvionSubmarinoTests.swift
//  AvionSubmarinoTests
//
//  Created by Zurisabdai Núñez Velázquez on 06/10/25.
//

import Testing
@testable import AvionSubmarino

struct AvionSubmarinoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
